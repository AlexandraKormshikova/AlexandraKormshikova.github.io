document.getElementById('mob_menu').onclick = function() {
  document.getElementById('header_mob').classList.toggle('none');
}
