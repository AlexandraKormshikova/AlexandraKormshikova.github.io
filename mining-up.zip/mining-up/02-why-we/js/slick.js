$(document).ready(function(){
    $('.slider').slick({
        arrows: false,
        dots: true,
    });
})
