$(document).ready(function(){
    $('.stable_slider').slick({
        arrows: false,
        dots: true,
    });
});
