document.getElementById('mob_menu').onclick = function() {
  document.getElementById('mob_menu_body').classList.remove('none');
}

document.getElementById('mob_menu_close').onclick = function() {
  document.getElementById('mob_menu_body').classList.add('none');
}
